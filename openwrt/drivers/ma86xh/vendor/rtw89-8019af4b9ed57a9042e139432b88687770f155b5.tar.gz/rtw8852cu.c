// SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause
/* Copyright(c) 2025  Realtek Corporation
 */

#include <linux/module.h>
#include <linux/usb.h>
#include "rtw8852c.h"
#include "reg.h"
#include "usb.h"

static const struct rtw89_usb_info rtw8852c_usb_info = {
	.usb_host_request_2		= R_AX_USB_HOST_REQUEST_2_V1,
	.usb_wlan0_1			= R_AX_USB_WLAN0_1_V1,
	.hci_func_en			= R_AX_HCI_FUNC_EN_V1,
	.usb3_mac_npi_config_intf_0	= R_AX_USB3_MAC_NPI_CONFIG_INTF_0_V1,
	.usb_endpoint_0			= R_AX_USB_ENDPOINT_0_V1,
	.usb_endpoint_2			= R_AX_USB_ENDPOINT_2_V1,
	.rx_agg_alignment		= 8,
	.bulkout_id = {
		[RTW89_DMA_ACH0] = 3,
		[RTW89_DMA_ACH2] = 5,
		[RTW89_DMA_ACH4] = 4,
		[RTW89_DMA_ACH6] = 6,
		[RTW89_DMA_B0MG] = 0,
		[RTW89_DMA_B0HI] = 0,
		[RTW89_DMA_B1MG] = 1,
		[RTW89_DMA_B1HI] = 1,
		[RTW89_DMA_H2C] = 2,
	},
};

static const struct rtw89_driver_info rtw89_8852cu_info = {
	.chip = &rtw8852c_chip_info,
	.variant = NULL,
	.board = NULL,
	.quirks = NULL,
	.dev_id_quirks = 0,
	.bus = {
		.usb = &rtw8852c_usb_info,
	},
};

static const struct rtw89_led_gpio_entry rtw8852cu_valve_led_gpios[] = {
	{
		.pin = 8,
		.color = LED_COLOR_ID_WHITE,
		.intensity = 0,
		.pinmux = {.addr = R_AX_GPIO8_15_FUNC_SEL,
			   .mask = GENMASK(3, 0),
			   .data = 0xf},
		.mode = {.addr = R_AX_GPIO_EXT_CTRL + 2, .data = BIT(0) | BIT(8)},
		.out = {.addr = R_AX_GPIO_EXT_CTRL + 1, .data = BIT(0)},
	}, {
		.pin = 18,
		.color = LED_COLOR_ID_RED,
		.intensity = 0,
		.pinmux = {.addr = R_AX_GPIO16_23_FUNC_SEL,
			   .mask = GENMASK(11, 8),
			   .data = 0xf},
		.mode = {.addr = R_AX_GPIO_16_TO_18_EXT_CTRL + 2,
			 .data = BIT(2) | BIT(10)},
		.out = {.addr = R_AX_GPIO_16_TO_18_EXT_CTRL + 1, .data = BIT(2)},
	}, {
		.pin = 16,
		.color = LED_COLOR_ID_GREEN,
		.intensity = 1,
		.pinmux = {.addr = R_AX_GPIO16_23_FUNC_SEL,
			   .mask = GENMASK(3, 0),
			   .data = 0xf},
		.mode = {.addr = R_AX_GPIO_16_TO_18_EXT_CTRL + 2,
			 .data = BIT(0) | BIT(8)},
		.out = {.addr = R_AX_GPIO_16_TO_18_EXT_CTRL + 1, .data = BIT(0)},
	}, {
		.pin = 17,
		.color = LED_COLOR_ID_BLUE,
		.intensity = 0,
		.pinmux = {.addr = R_AX_GPIO16_23_FUNC_SEL,
			   .mask = GENMASK(7, 4),
			   .data = 0xf},
		.mode = {.addr = R_AX_GPIO_16_TO_18_EXT_CTRL + 2,
			 .data = BIT(1) | BIT(9)},
		.out = {.addr = R_AX_GPIO_16_TO_18_EXT_CTRL + 1, .data = BIT(1)},
	},
};

static const struct rtw89_led_desc rtw8852cu_valve_led_desc = {
	.gpios = rtw8852cu_valve_led_gpios,
	.n_gpio = ARRAY_SIZE(rtw8852cu_valve_led_gpios),
};

static const struct rtw89_board_variant rtw89_8852cu_valve_board = {
	.id = RTW89_BOARD_ID(28de, 2432),
	.led_desc = &rtw8852cu_valve_led_desc,
};

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 9, 0)
static const struct rtw89_driver_info rtw89_8852cu_valve_info = {
	.chip = &rtw8852c_chip_info,
	.variant = NULL,
	.board = &rtw89_8852cu_valve_board,
	.quirks = NULL,
	.dev_id_quirks = BIT(RTW89_QUIRK_HW_INFO_SYSFS) |
			 BIT(RTW89_QUIRK_DISABLE_2GHZ),
	.bus = {
		.usb = &rtw8852c_usb_info,
	},
};
#endif

static const struct usb_device_id rtw_8852cu_id_table[] = {
	{ USB_DEVICE_AND_INTERFACE_INFO(0x0411, 0x03a6, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x056e, 0x4024, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x0bda, 0xc832, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x0bda, 0xc85a, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x0bda, 0xc85d, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x0db0, 0x991d, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x2357, 0x014d, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x28de, 0x2432, 0xff, 0xff, 0xff),
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 9, 0)
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_valve_info },
#else
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
#endif
	{ USB_DEVICE_AND_INTERFACE_INFO(0x2c4e, 0x0127, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x2c7c, 0x8206, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x35b2, 0x0502, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x35bc, 0x0101, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x35bc, 0x0102, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x37ad, 0x0103, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x37ad, 0x0107, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x37ad, 0x0108, 0xff, 0xff, 0xff),
	  .driver_info = (kernel_ulong_t)&rtw89_8852cu_info },
	{},
};
MODULE_DEVICE_TABLE(usb, rtw_8852cu_id_table);

static int rtw8852cu_probe(struct usb_interface *intf,
			   const struct usb_device_id *id)
{
	return rtw89_usb_probe(intf, id, &rtw89_8852cu_info);
}

static struct usb_driver rtw_8852cu_driver = {
	.name = KBUILD_MODNAME,
	.id_table = rtw_8852cu_id_table,
	.probe = rtw8852cu_probe,
	.disconnect = rtw89_usb_disconnect,
};
module_usb_driver(rtw_8852cu_driver);

MODULE_AUTHOR("Bitterblue Smith <rtl8821cerfe2@gmail.com>");
MODULE_DESCRIPTION("Realtek 802.11ax wireless 8852CU driver");
MODULE_LICENSE("Dual BSD/GPL");
